package com.ws.sip.sip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SipApplication {

	public static void main(String[] args) {
		SpringApplication.run(SipApplication.class, args);
	}

}
